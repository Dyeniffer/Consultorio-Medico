SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `consultorio` DEFAULT CHARACTER SET latin1 ;
USE `consultorio` ;

-- -----------------------------------------------------
-- Table `consultorio`.`tb_pacientes`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `consultorio`.`tb_pacientes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `nome` VARCHAR(200) NOT NULL ,
  `rg` VARCHAR(15) NOT NULL UNIQUE,
  `endereco` VARCHAR(200) NOT NULL ,
  `telefone` VARCHAR(15) NULL DEFAULT NULL ,
  `data_nasc` DATE NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `consultorio`.`tb_consultas`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `consultorio`.`tb_consultas` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `prontuario` TEXT NULL DEFAULT NULL ,
  `dth` DATE NULL DEFAULT NULL ,
  `estado` TINYINT(1) NULL DEFAULT NULL ,
  `id_paciente` INT(11) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `id_paciente` (`id_paciente` ASC) ,
  CONSTRAINT `tb_consultas_ibfk_1`
    FOREIGN KEY (`id_paciente` )
    REFERENCES `consultorio`.`tb_pacientes` (`id` ))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `consultorio`.`tb_medicamentos`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `consultorio`.`tb_medicamentos` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `nome` VARCHAR(200) NOT NULL ,
  `quantidade` VARCHAR(200) NOT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `consultorio`.`tb_receituarios`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `consultorio`.`tb_receituarios` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `id_medicamento` INT(11) NULL DEFAULT NULL ,
  `topologia` TEXT NOT NULL ,
  `id_consulta` INT(11) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `id_medicamento` (`id_medicamento` ASC) ,
  CONSTRAINT `tb_receituarios_ibfk_1`
    FOREIGN KEY (`id_medicamento` )
    REFERENCES `consultorio`.`tb_medicamentos` (`id` ),
  CONSTRAINT `tb_receituarios_ibfk_2`
    FOREIGN KEY (`id_consulta` )
    REFERENCES `consultorio`.`tb_consultas` (`id` )
    ON DELETE RESTRICT
    ON UPDATE RESTRICT)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

USE `consultorio` ;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
