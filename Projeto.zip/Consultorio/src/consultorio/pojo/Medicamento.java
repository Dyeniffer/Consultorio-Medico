/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package consultorio.pojo;

/**
 *
 * @author 631210057
 */
public class Medicamento {
    
    public int id;
    public String nome;
    public int quantidade;
    
   public Medicamento(int id, String nome, int quantidade){
       this.id =id;
       this.nome = nome;
       this.quantidade = quantidade;
       
   } 
   
   public Medicamento(String nome, int quantidade){
       this.nome = nome;
       this.quantidade = quantidade;
       
   } 
   
   public int getId() {
        return id;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getQuant() {
        return quantidade;
    }

    public void set(int quantidade) {
        this. quantidade = quantidade;
    }
    
    @Override
    public String toString() {
		return "medicamento [id=" + id+ ", nome=" + nome + ", quantidade=" + quantidade + "]";
	}
    
}
