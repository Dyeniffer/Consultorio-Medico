/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package consultorio.pojo;

/**
 *
 * @author 631210057
 */
public class Paciente {

    public int id;
    public String nome;
    public String data_nasc;
    private String rg;
    public String endereco;
    public String telefone;
    
    public Paciente(int id,String nome, String data_nasc, String rg, String endereco, String telefone){
        this.id = id;
        this.nome = nome;
        this.data_nasc = data_nasc;
        this.rg = rg;
        this.endereco = endereco;
        this.telefone = telefone;
        
    }
    
    public Paciente(String nome, String data_nasc, String rg, String endereco, String telefone){
        this.nome = nome;
        this.data_nasc = data_nasc;
        this.rg = rg;
        this.endereco = endereco;
        this.telefone = telefone;
        
    }

    public int getId() {
		return id;
	}

    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getDataNasc() {
        return data_nasc;
    }

    public void set(String data_nasc) {
        this. data_nasc = data_nasc;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    @Override
    public String toString() {
		return "paciente [id=" + id+ ", nome=" + nome + ", data de nascimento=" + data_nasc +  ", rg=" + rg +
                        ", endereço=" + endereco + ", telefone=" + telefone + "]";
	}
    
}
