/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package consultorio.dao;

import consultorio.pojo.Paciente;

import java.util.ArrayList;
import java.util.List;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
/**
 *
 * @author 631210057
 */
public class PacienteDAO {
    
    public Paciente findPacByNome(String  nome) {
		Paciente pac = null;
		String cmd = "SELECT * FROM tb_pacientes WHERE nome = ?";

		Connection db = null;
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			// ABRIR CONEXÃO
			Properties props = new Properties();
			props.load(new FileInputStream("consultorio.properties"));
			String url = props.getProperty("url");

			db = DriverManager.getConnection(url, props);

			st = db.prepareStatement(cmd);
			st.setString(1,nome);
			rs = st.executeQuery();

			while (rs.next()) {

				String nomeBD = rs.getString("nome");
				String rg = rs.getString(2);
                                String data_nasc = rs.getString(3);
                                String endereco = rs.getString(4);
                                String telefone = rs.getString(5);
				pac = new Paciente(nomeBD,rg,data_nasc,endereco,telefone);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (db != null) {
					db.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return pac;
	}

	public void insertPac(Paciente pac) {
		String cmd = "INSERT INTO tb_pacientes (nome,rg,data_nasc,endereco,telefone) VALUES (?, ?, ?, ?, ?)";
		Connection db = null;
		PreparedStatement st = null;

		try {
			// ABRIR CONEXÃO
			Properties props = new Properties();
			props.load(new FileInputStream("consultorio.properties"));
			String url = props.getProperty("url");

			db = DriverManager.getConnection(url, props);

			st = db.prepareStatement(cmd);
			st.setString(1, pac.getNome());
			st.setString(2, pac.getRg());
                        st.setString(3, pac.getDataNasc());
                        st.setString(4, pac.getEndereco());
                        st.setString(5, pac.getTelefone());
			
			int r = st.executeUpdate();

			if (r != 1) {
				throw new RuntimeException("ERRO AO INSERIR O PACIENTE!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (st != null) {
					st.close();
				}
				if (db != null) {
					db.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public List<Paciente> findPacByPac(){
	List<Paciente> listPac = new ArrayList<Paciente>();
        String cmd = "SELECT * FROM tb_pacientes";
		Connection db = null;
        PreparedStatement st = null;
        ResultSet rs = null;

        try {
                Properties props = new Properties();
                props.load(new FileInputStream("consultorio.properties"));
                String url = props.getProperty("url");

                db = DriverManager.getConnection(url, props);

                st = db.prepareStatement(cmd);
            
                rs = st.executeQuery();

                while (rs.next()) {
                                int id = rs.getInt(1);
                                String nome = rs.getString(2);
    				String rg = rs.getString(3);
                                String data_nasc = rs.getString(4);
                                String endereco = rs.getString(5);
                                String telefone = rs.getString(6);
    				
    				
                    listPac.add(new Paciente (id,nome,rg,data_nasc,endereco,telefone));
                }

        } catch (Exception e) {
                e.printStackTrace();
        } finally {
                try {
                        if (rs != null) {
                                rs.close();
                        }
                        if (st != null) {
                                st.close();
                        }
                        if (db != null) {
                                db.close();
                        }
                } catch (Exception e2) {
                        e2.printStackTrace();
                }
        }
        return listPac;
}
    
    
}

