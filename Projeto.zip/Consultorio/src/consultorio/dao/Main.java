/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package consultorio.dao;
 
import consultorio.pojo.Medicamento;

/**
 *
 * @author 631210057
 */
public class Main {
    public static void main(String[] args) {
        Medicamento m = new Medicamento("P",120);
        MedicamentoDAO md = new MedicamentoDAO();
        md.insertMed(m);
        
    }
}
