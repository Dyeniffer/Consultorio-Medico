/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package consultorio.dao;
 
import consultorio.pojo.Medicamento;

import java.util.ArrayList;
import java.util.List;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
/**
 *
 * @author 631210057
 */
public class MedicamentoDAO {
    
    public Medicamento findMedByNome(String  nome) {
		Medicamento med = null;
		String cmd = "SELECT * FROM tb_medicamentos WHERE nome = ?";

		Connection db = null;
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			// ABRIR CONEXÃO
			Properties props = new Properties();
			props.load(new FileInputStream("consultorio.properties"));
			String url = props.getProperty("url");

			db = DriverManager.getConnection(url, props);

			st = db.prepareStatement(cmd);
			st.setString(1,nome);
			rs = st.executeQuery();

			while (rs.next()) {

				String nomeBD = rs.getString("nome");
				int quantidade = rs.getInt(2);
				med = new Medicamento(nomeBD, quantidade);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (db != null) {
					db.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return med;
	}

	public void insertMed(Medicamento med) {
		String cmd = "INSERT INTO tb_medicamentos (nome,quantidade) VALUES (?, ?)";
		Connection db = null;
		PreparedStatement st = null;

		try {
			// ABRIR CONEXÃO
			Properties props = new Properties();
			props.load(new FileInputStream("consultorio.properties"));
			String url = props.getProperty("url");

			db = DriverManager.getConnection(url, props);

			st = db.prepareStatement(cmd);
			st.setString(1, med.getNome());
			st.setInt(2, med.getQuant());
			
			int r = st.executeUpdate();

			if (r != 1) {
				throw new RuntimeException("ERRO AO INSERIR O MEDICAMENTO!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (st != null) {
					st.close();
				}
				if (db != null) {
					db.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public List<Medicamento> findMedByMed(){
	List<Medicamento> listMed = new ArrayList<Medicamento>();
        String cmd = "SELECT * FROM tb_medicamentos";
		Connection db = null;
        PreparedStatement st = null;
        ResultSet rs = null;

        try {
                Properties props = new Properties();
                props.load(new FileInputStream("consultorio.properties"));
                String url = props.getProperty("url");

                db = DriverManager.getConnection(url, props);

                st = db.prepareStatement(cmd);
            
                rs = st.executeQuery();

                while (rs.next()) {
                                int id = rs.getInt(1);
                                String nome = rs.getString(2);
    				int quantidade = rs.getInt(3);
    				
    				
                    listMed.add(new Medicamento (id,nome,quantidade));
                }

        } catch (Exception e) {
                e.printStackTrace();
        } finally {
                try {
                        if (rs != null) {
                                rs.close();
                        }
                        if (st != null) {
                                st.close();
                        }
                        if (db != null) {
                                db.close();
                        }
                } catch (Exception e2) {
                        e2.printStackTrace();
                }
        }
        return listMed;
}
    
    
}
